#!/system/bin/sh
# 管理器卸载时收尾：交给 cleanup.sh 做本地清理（停守护 / 撤遮蔽 / 删 backing / 删数据）。
MODDIR=${0%/*}
if [ -x "$MODDIR/bin/cleanup.sh" ]; then
    sh "$MODDIR/bin/cleanup.sh" purge-local >/dev/null 2>&1
else
    . "$MODDIR/bin/common.sh" 2>/dev/null
    _p=$(cat "$PID_F" 2>/dev/null)
    case "$_p" in ''|*[!0-9]*) ;; *) kill -9 "$_p" 2>/dev/null ;; esac
    sh "$MODDIR/bin/hide.sh" undo >/dev/null 2>&1
    rm -rf "$MODDIR/data" /data/local/.modbacking /data/local/.sincerity.stage 2>/dev/null
fi
exit 0
