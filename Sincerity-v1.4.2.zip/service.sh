#!/system/bin/sh
# 开机拉起守护进程。WebUI 有卡密锁，所以守护/遮蔽/卸载照常跑，不受锁影响。
MODDIR=${0%/*}
[ -f "$MODDIR/disable" ] && exit 0
D="$MODDIR/bin/daemon.sh"
[ -x "$D" ] || exit 0
if command -v nohup >/dev/null 2>&1; then
    nohup sh "$D" >/dev/null 2>&1 &
else
    sh "$D" >/dev/null 2>&1 &
fi
exit 0
