# Sincerity · 天上天下唯我独尊

自己写的 Magisk / KernelSU / APatch 模块：开机卸载 OPPO 系（OPPO / 一加 / 真我）
的 inte 内核完整性检测模块，可选把 `.ko` 文件一起藏起来。**没有卡密，没有联网校验。**

## 原理

1. `post-fs-data.sh`：系统刚挂载完、应用还没起来时先卸一次（这时最干净）。
2. `service.sh`：拉起 `bin/daemon.sh`，按间隔（默认 5s）复核 `/proc/modules`，
   发现 `inte` / `oplus_integrity` / `oplus_kohashpro` 就 `rmmod`。
3. `bin/hide_ko.sh`：可选。**tmpfs 接管** `/vendor_dlkm/lib/modules`（以及 `/odm`、`/system` 下同路径），
   目录里只挂其它 `.ko` 的软链，`inte*.ko` 直接从磁盘视图里消失——不是 0 字节占位。
   实现用 tmpfs + 软链 farm，backing 缓存在 `/data/local/.modbacking`。

## 卡密（WebUI 锁）

没解锁时整个 WebUI 被一块全屏遮罩挡住，输入卡密才能用。

- 默认卡密：**Sincerity520NB**（大小写、空格、短横线都不影响）
- 卡密本身**不落盘**，只存 `sha256("SINCERITY-V1|sincerity|<卡密>") ` 的前 16 位，写在 `bin/auth.sh` 的 `AUTH_CHECK`
- 解锁后写 `data/auth.ok` + `data/auth.name`，重启/重开页面都保持解锁
- 改卡密：`node tmp/genkey.js sincerity 新卡密` 算出校验值，替换 `bin/auth.sh` 里的 `AUTH_CHECK`，重新打包
- 忘了卡密：删掉 `data/auth.ok` 和 `data/auth.name`，或重装模块（会回到未解锁）
- 命令行：`ctl.sh auth login <卡密>` / `auth logout` / `auth check`

**这不是加密**：卡密校验在模块脚本里，root 环境下拿到文件的人一定能绕。它的作用是防随手转包、防别人拿你的模块直接用，别指望它挡得住会逆向的人。

## 功能

- **开机卸载**：post-fs-data 先卸一次，守护进程按间隔复核
- **两种模式**：unload 卸载 / monitor 只观察
- **文件遮蔽**：tmpfs 接管模块目录 + 软链 farm，`inte*.ko` 消失；可随时 umount 还原
- **游戏缓存守护**：只清陈旧缓存 / 孤儿临时文件 / 过期日志，白名单 glob + 年龄校验 + 试跑
- **Key / TEE 检测**：KeyMint 实现方、TEE 服务、Attestation 状态，只读
- **修复包安装器**：内置 3 个 TEE / Key 修复包（离线可用），WebUI 里两段确认即可安装；自己准备的 zip 放进 /sdcard/Sincerity/fixes/ 也会一起列出，先校验 module.prop 再交给 magisk/ksud/apd
- **管理器更新**：`module.prop` 里写 `updateJson=`，管理器模块页直接亮「更新」；模块内不再自带更新器

## WebUI 兼容性

`window.ksu` 在 KernelSU / SukiSU 里是 Java 接口，签名是 `exec(cmd, optionsJson, 回调名)`，回调名会被原样拼进 `evaluateJavascript`——直接传 JS 函数或对象，WebView 只会回一句
`Java exception was raised during method invocation`。

所以 `app.js` 里不再直接传函数：先拿 `echo ksu-probe` 试出管理器支持哪种调用方式（名字回调 / 函数回调 / 同步返回），试通后全程复用，并且把命令串行化，避免并发把管理器的 root shell 顶崩。

## 更新（只用管理器）

模块自己**不再做**更新检查 / 下载 / 安装。更新只有一个入口：`module.prop` 里的

```
updateJson=https://0033333.github.io/sincerity/update.json
```

用户在管理器的「模块」页就能看到「更新」按钮，点一下由管理器自己下载安装；点开时显示的更新说明来自
`changelog` 链接（Markdown）。WebUI 只显示运行状态和各项开关，没有更新按钮。

管理器端亮更新键的条件（SukiSU / KernelSU 一致）：模块启用中、`updateJson` 返回 200 的 JSON、
`versionCode` 比本地大、`zipUrl` 非空。`changelog` 必须是 Markdown 链接。

### 发版

```sh
node publish.js https://0033333.github.io/sincerity
node upload.js
```

- `publish.js`：`versionCode` +1、写 `updateJson=`、打包 `Sincerity-vX.Y.Z.zip`、生成 `update.json`
- `upload.js`：用 `.gh_token` 里的令牌把 `update.json`、`CHANGELOG.md`、zip 提交到 GitHub
- 仓库开了 GitHub Pages，提交后 Pages 自动重建；raw / jsDelivr 也能访问同一份文件

如果哪台机器上 github.io 打不开，可以把 `updateJson` 换成 jsDelivr 的同一份（管理器只认一个地址）：

```
https://fastly.jsdelivr.net/gh/0033333/sincerity@main/update.json
```

## TEE 修复（一键修复）

WebUI 的 TEE 页 → 「一键修复 Key 状态」，走的是标准的 4 步：

1. 刷入 `01-TEE-AutoList`
2. 刷入 `02-TEESimulator-RS`（模块 id 是 `tricky_store`，会覆盖同名模块）
3. 仅 OPPO 系（一加 / OPPO / 真我 / ColorOS）才刷 `03-fix-key-state`
4. 烧录密钥：用 Termux 的 bash 执行 `04-burn-key.sh`

细节：

- `data/keyfix.log` 是完整修复日志，`data/keyfix_progress` 是进度（`1/4`…`4/4`、`完成`）
- 有目录锁 `data/keyfix.lock.d`，重复点击会被拒绝（进度显示「已有修复在跑（Ns）」）；进程被强杀后 30 分钟自动解锁
- `key.sh --dry-run` 只写日志不刷包；`key.sh --log [n]` 看日志；`ctl.sh kf repair|log|dry`

### Termux 自动安装

第 4 步需要 Termux（`04-burn-key.sh` 是 Termux 自解压脚本）。没装时模块会：

1. 从本项目 Pages 下 Termux 0.118.3 arm64 包（备用：jsDelivr、GitHub 直连）
2. 校验：体积必须等于 `35106607`、ZIP 魔数、**SHA256 必须在白名单里**
   （`72fdb596…3a4e`）——任一条不过就换源，全不过就跳过第 4 步，绝不装来路不明的包
3. `pm install` → 失败退到 `install-create/install-write/install-commit` → 再失败退到 `pm install -r -d`
4. 装好后拉起 Termux 解包 bootstrap，等 `/data/data/com.termux/files/usr/bin/bash` 就绪
5. 用它的 bash 跑烧录脚本；脚本退出码非 0 但产出了 `/data/local/tmp/LING` 也算成功

APK 缓存在 `keyfix/05-Termux.apk`，下次直接用。

## 内置修复包

随模块打包，在 `keyfix/` 下，不联网、不改别人的服务器，只是把包放在本机：

| 包 | 模块 id | 作用 |
|---|---|---|
| `01-TEE-AutoList.zip` | `TEE_AutoList` | 自动维护白名单（用户排除 + 系统添加），Cron 定时触发 |
| `02-TEESimulator-RS.zip` | `tricky_store` | TEESimulator-RS，软件模拟硬件 attestation |
| `03-fix-key-state.zip` | `jiemosi_auto_fix_rkp_soter_key` | 自动修 Soter Key，手动一键修 RKP |

装法有三种，效果一样，都是交给当前管理器安装：

1. WebUI →「Key 状态 · TEE」→ 点包右边「安装」，再点一次确认；
2. `sh /data/adb/modules/sincerity/bin/ctl.sh kf install 1`（序号 / 文件名 / 名字片段都行）；
3. 直接 `sh /data/adb/modules/sincerity/bin/key.sh --list` 看清单。

**装完要重启才生效。** 外置包目录 `/sdcard/Sincerity/fixes/` 仍然可用，放进去的 zip 会排在后面一起列出。
包里已经是完整的模块（带自己的 service.sh / 原生库），所以三个包之间、和本模块之间不要重复装同一类。

## 保护名单

以下模块**永远不会**被卸载（动了可能掉摄像头、掉快充甚至开不了机）：

`cdt_integrity` `msm_core` `qmi_helpers` `trusted_core`

## 参数

| 文件 | 含义 | 默认 |
|---|---|---|
| `data/mode` | `unload` 卸载 / `monitor` 只看不动 | unload |
| `data/interval` | 复核间隔（秒，2–300） | 5 |
| `data/mask` | 是否开启文件遮蔽（tmpfs 接管） | 0 |

WebUI 里点一下就是改这些文件，改完守护进程下一轮自动生效。

## 排查

```sh
sh /data/adb/modules/sincerity/bin/selfcheck.sh   # 环境、目标、挂载、进程
sh /data/adb/modules/sincerity/bin/status.sh      # WebUI 用的状态
tail -f /data/adb/modules/sincerity/data/daemon.log
```

## 卸载

管理器里卸载即可，`uninstall.sh` 会停守护进程并撤掉所有 bind mount，
不会把遮蔽留在系统里。

## 风险

- 卸载厂商完整性模块会影响依赖它的风控（银行、支付、部分游戏），可能被判定设备异常。
- 遮蔽 `.ko` 会让检查文件完整性的工具（Hunter 等）报警，二者不能共存。
- 只在自己的机器上用。
