#!/system/bin/sh
SKIPUNZIP=0

ui_print " "
ui_print "*******************************"
ui_print "  Sincerity · 天上天下唯我独尊"
ui_print "  by 阿毅   QQ 1043298231"
ui_print "*******************************"
ui_print " "
ui_print "- 环境: $ARCH / API $API"
[ -n "$KSU_VER" ] && ui_print "- KernelSU $KSU_VER"
ui_print "- 目标: 卸载 inte 系列内核模块（inte / oplus_integrity / oplus_kohashpro）"
ui_print "- 默认模式: 卸载；可在 WebUI 切成监控模式"
ui_print "- 危险动作一律不做: cdt_integrity / msm_core / qmi_helpers 在保护名单"
ui_print "- 内置修复包: TEE_AutoList / TEESimulator-RS / 修复Key状态（WebUI 里一键装）"
ui_print "- 文件遮蔽: tmpfs 接管模块目录，inte*.ko 直接消失"

# 升级：先撤掉旧版遮蔽，别把 tmpfs / backing 留在系统里
if [ -x /data/adb/modules/sincerity/bin/hide.sh ]; then
    _r=$(sh /data/adb/modules/sincerity/bin/hide.sh undo 2>/dev/null)
    ui_print "- 已撤销旧版遮蔽: ${_r:-无}"
fi

mkdir -p "$MODPATH/data"
# 保住上一版的设置（模式/间隔/遮蔽开关/游戏守护配置/更新地址）
if [ -d /data/adb/modules/sincerity/data ]; then
    cp -a /data/adb/modules/sincerity/data/. "$MODPATH/data/" 2>/dev/null
fi
[ -f "$MODPATH/data/mode" ] || echo unload >"$MODPATH/data/mode"
[ -f "$MODPATH/data/interval" ] || echo 5 >"$MODPATH/data/interval"
[ -f "$MODPATH/data/mask" ] || echo 0 >"$MODPATH/data/mask"
: >"$MODPATH/data/daemon.log"

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
set_perm "$MODPATH/bin/cleanup.sh" 0 0 0755

# 覆盖安装：把上一版留下的旧文件 / 旧挂载 / 旧缓存清掉（数据已在上一步保住了）
if [ -x "$MODPATH/bin/cleanup.sh" ]; then
    _c=$(sh "$MODPATH/bin/cleanup.sh" clean 2>&1 | tail -3)
    ui_print "- 覆盖安装清理: ${_c:-完成}"
fi

set_perm_recursive "$MODPATH/keyfix" 0 0 0755 0644
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
set_perm "$MODPATH/customize.sh" 0 0 0755
