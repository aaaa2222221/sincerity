#!/system/bin/sh
# 管理器里点模块的「执行」按钮就跑这里。
MODDIR=${0%/*}
. "$MODDIR/bin/common.sh" 2>/dev/null

echo "===== Sincerity · 天上天下唯我独尊 · 手动执行 ====="
echo "模式: $(mode)  间隔: $(interval)s"
_l=$(loaded)
if [ -z "$_l" ]; then
    _n=$(nodes)
    if [ "$_n" -gt 0 ]; then
        echo "未加载，但有 $_n 个 /proc 节点：可能是内建形态"
    else
        echo "inte 未加载，当前就是干净状态"
    fi
    exit 0
fi
echo "检测到: $_l"
for _m in $_l; do
    _out=$(unload_mod "$_m" 2>&1)
    echo "rmmod $_m => ${_out:-成功}"
done
if [ -z "$(loaded)" ]; then
    set_state normal
    echo "清除成功 ✅"
else
    set_state failed
    echo "仍有残留 ❌"
fi
