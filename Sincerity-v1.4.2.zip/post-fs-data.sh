#!/system/bin/sh
# 开机早期阶段：开机后应用还没起来，这时候卸载 / 遮蔽最干净。
MODDIR=${0%/*}
[ -f "$MODDIR/disable" ] && exit 0

. "$MODDIR/bin/common.sh"
mkdir -p "$DATA" 2>/dev/null

[ -f "$MODE_F" ] || echo unload >"$MODE_F"
[ -f "$IV_F" ] || echo 5 >"$IV_F"

# ① 目录遮蔽：要开过才有，恢复的是上次的列表
if mask_on; then
    sh "$MODDIR/bin/hide.sh" apply >>"$LOG_F" 2>&1
fi

# ② 卸载：只有卸载模式才动
if [ "$(mode)" = "unload" ]; then
    _l=$(loaded)
    if [ -n "$_l" ]; then
        for _m in $_l; do
            _out=$(unload_mod "$_m")
            log "boot" "rmmod $_m => ${_out:-成功}"
        done
        [ -z "$(loaded)" ] && set_state normal || set_state failed
    else
        set_state normal
    fi
fi
exit 0
