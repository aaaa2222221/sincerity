/* 天上天下唯我独尊 · Sincerity —— WebUI 逻辑
 * 自己的实现；只依赖 KernelSU 的 window.ksu.exec 桥。
 * 带 mock 模式（地址加 ?mock=1）方便在浏览器里调样式，不碰真机。
 */
(function () {
  'use strict';

  var MOD = '/data/adb/modules/sincerity';
  var POLL = 8000;
  var MOCK = /(^|[?&])mock=1/.test(location.search);

  var $ = function (id) { return document.getElementById(id); };
  var el = {
    ver: $('ver'), ver2: $('ver2'),
    hero: document.querySelector('.hero'),
    stateTxt: $('stateTxt'), stateSub: $('stateSub'), chip: $('chip'),
    vLoaded: $('vLoaded'), vNodes: $('vNodes'), vDaemon: $('vDaemon'),
    vUptime: $('vUptime'), vMask: $('vMask'), vMode: $('vMode'),
    vLoadedSub: $('vLoadedSub'), vNodesSub: $('vNodesSub'), vDaemonSub: $('vDaemonSub'),
    vUptimeSub: $('vUptimeSub'), vMaskSub: $('vMaskSub'), vModeSub: $('vModeSub'),
    vModel: $('vModel'), vKernel: $('vKernel'), vRoot: $('vRoot'),
    segMode: $('segMode'), segIv: $('segIv'), modeHint: $('modeHint'),
    btnClear: $('btnClear'), btnRefresh: $('btnRefresh'), btnMask: $('btnMask'),
    log: $('log'), logFold: $('logFold'), toast: $('toast'),
    vMaskActive: $('vMaskActive'), vMasked: $('vMasked'),
    btnGame: $('btnGame'), gameDesc: $('gameDesc'), vGameHits: $('vGameHits'),
    vGameDel: $('vGameDel'), btnGameDry: $('btnGameDry'), btnGameScan: $('btnGameScan'),
    btnGameLog: $('btnGameLog'), gameLog: $('gameLog'),
    vGameBytes: $('vGameBytes'), vGameLast: $('vGameLast'),
    vKm: $('vKm'), vTee: $('vTee'), vAtt: $('vAtt'),
    btnKfScan: $('btnKfScan'), btnKfPacks: $('btnKfPacks'), kfLog: $('kfLog'),
    vKfMods: $('vKfMods'), vKfPacks: $('vKfPacks'), btnKfFix: $('btnKfFix'),
    btnKfLog: $('btnKfLog'), kfStatus: $('kfStatus'),
    teeDesc: $('teeDesc'), teeDescToggle: $('teeDescToggle'),
    vKfBurn: $('vKfBurn'), teeLog: $('teeLog'), teeLogFold: $('teeLogFold'),
    btnCleanup: $('btnCleanup'), btnUninstall: $('btnUninstall'),
    kfPacks: $('kfPacks'),
  };

  // ── 桥：各家管理器的 exec ABI 不一样，这里自适应 ───────────────────────
  // KernelSU / SukiSU 的 window.ksu 是 Java 接口，签名 (cmd, optionsJson, 回调名)，
  // 回调名会被原样拼进 evaluateJavascript——所以不能直接传 JS 函数/对象，
  // 否则 WebView 只会甩一句 "Java exception was raised during method invocation"。
  var ABIS = ["name3", "name2", "fn3", "fn2", "ret"];
  var ABI = null, SEQ = 0, queue = Promise.resolve();

  function bridge() {
    var ksu = window.ksu;
    if (!ksu || typeof ksu.exec !== "function") throw new Error("管理器的执行接口不可用（不是从管理器打开的？）");
    return ksu;
  }

  function rawExec(abi, cmd, cbName) {
    var ksu = bridge();
    var fn = window[cbName];
    var wrap = function (c, o, e) { if (typeof fn === "function") fn(c, o, e); };
    switch (abi) {
      case "name3": ksu.exec(cmd, JSON.stringify({ cwd: "/" }), "window." + cbName); break;
      case "name2": ksu.exec(cmd, "window." + cbName); break;
      case "fn3":   ksu.exec(cmd, { cwd: "/" }, wrap); break;
      case "fn2":   ksu.exec(cmd, wrap); break;
      case "ret":   wrap(0, ksu.exec(cmd), ""); break;
      default: throw new Error("未知调用方式 " + abi);
    }
  }

  // 用一条无害命令试出哪种调用方式真正能跑通，之后全程复用
  function detectAbi() {
    if (ABI) return Promise.resolve(ABI);
    try { bridge(); } catch (e) { return Promise.reject(e); }
    return new Promise(function (resolve, reject) {
      var i = 0;
      (function next() {
        if (i >= ABIS.length) { reject(new Error("执行接口不兼容：管理器没有回调")); return; }
        var abi = ABIS[i++];
        var name = "__ksu_probe_" + (++SEQ);
        var done = false;
        var timer = null;
        window[name] = function (code, out) {
          if (done) return;
          done = true;
          clearTimeout(timer);
          delete window[name];
          if (String(out || "").indexOf("ksu-probe") >= 0) { ABI = abi; resolve(abi); }
          else next();
        };
        timer = setTimeout(function () {
          if (done) return;
          done = true;
          delete window[name];
          next();
        }, 1500);
        try { rawExec(abi, "echo ksu-probe", name); }
        catch (e) {
          clearTimeout(timer);
          done = true;
          delete window[name];
          next();
        }
      })();
    });
  }

  function runExec(cmd) {
    return detectAbi().then(function (abi) {
      if (abi === "ret") {
        try { return String(bridge().exec(cmd) || ""); }
        catch (e) { throw e; }
      }
      return new Promise(function (resolve, reject) {
        var name = "__ksu_cb_" + (++SEQ);
        var done = false;
        window[name] = function (code, out, err) {
          if (done) return;
          done = true;
          clearTimeout(timer);
          delete window[name];
          if (code === 0 || out) resolve(String(out || ""));
          else reject(new Error(String(err || ("exit " + code))));
        };
        var timer = setTimeout(function () {
          if (done) return;
          done = true;
          delete window[name];
          reject(new Error("执行超时（" + abi + "）"));
        }, 30000);
        try { rawExec(abi, cmd, name); }
        catch (e) {
          clearTimeout(timer);
          done = true;
          delete window[name];
          reject(e);
        }
      });
    });
  }

  // 串行执行：同一时刻只跑一条，避免并发把管理器的 shell 弄崩
  function sh(cmd) {
    if (MOCK) {
      try { return Promise.resolve(mockRun(cmd)); }
      catch (e) { return Promise.reject(e); }
    }
    var p = queue.then(function () { return runExec(cmd); });
    queue = p.then(function () {}, function () {});
    return p;
  }

  function toast(msg) {
    if (!el.toast) return;
    el.toast.textContent = msg;
    el.toast.className = 'toast show';
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { el.toast.className = 'toast'; }, 1800);
  }

  // ── 解析 status.sh 的 key=value ───────────────────────────────────────
  function parse(out) {
    var o = {};
    String(out || '').split('\n').forEach(function (line) {
      var i = line.indexOf('=');
      if (i <= 0) return;
      o[line.slice(0, i).trim()] = line.slice(i + 1).trim();
    });
    return o;
  }

  function b64utf8(b64) {
    if (!b64) return '';
    try {
      return decodeURIComponent(escape(atob(b64)));
    } catch (e) {
      try { return atob(b64); } catch (e2) { return ''; }
    }
  }

  function human(sec) {
    var s = parseInt(sec, 10);
    if (isNaN(s) || s < 0) return '—';
    var d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
    if (d > 0) return d + ' 天 ' + h + ' 小时';
    if (h > 0) return h + ' 小时 ' + m + ' 分';
    return m + ' 分';
  }

  var STATE = {
    normal:  { cls: 'ok',    txt: '已生效',   sub: 'inte 不在内核里，检测节点为零' },
    failed:  { cls: 'bad',   txt: '清除失败', sub: '目标仍在内核中，看日志里的 rmmod 输出' },
    builtin: { cls: 'warn',  txt: '内建模块', sub: '编译进内核的形态，用户态卸不掉' },
    monitor: { cls: 'watch', txt: '监控中',   sub: '发现目标只记录，不卸载' },
    idle:    { cls: '',      txt: '待命',     sub: '守护进程还没跑过一轮' }
  };

  function render(d) {
    var st = STATE[d.state] || STATE.idle;
    if (d.unlocked === '1') {
      if (!UNLOCKED) { UNLOCKED = true; lockShow(false); }
    } else {
      UNLOCKED = false;
      lockShow(true);
    }
    el.hero.className = 'card hero ' + st.cls;
    el.stateTxt.textContent = st.txt;
    el.stateSub.textContent = st.sub;
    el.chip.textContent = d.daemon === '1' ? '守护运行中' : '守护未运行';
    if (el.chip) el.chip.className = 'chip ' + (d.daemon === '1' ? 'on' : 'off');

    el.ver.textContent = d.version || '—';
    if (el.ver2 && d.version) el.ver2.textContent = d.version;

    var hasMod = (d.loaded && d.loaded !== '-');
    el.vLoaded.textContent = hasMod ? d.loaded : '未加载';
    el.vLoaded.className = 'v' + (hasMod ? ' warn' : ' ok');
    if (el.vLoadedSub) el.vLoadedSub.textContent = hasMod ? '内核里还在' : '/proc/modules 干净';

    el.vNodes.textContent = d.nodes || '0';
    el.vNodes.className = 'v mono' + ((parseInt(d.nodes, 10) || 0) > 0 ? ' warn' : ' ok');
    if (el.vNodesSub) el.vNodesSub.textContent = ((parseInt(d.nodes, 10) || 0) > 0) ? '仍有检测节点' : '/proc 节点 0/3';

    el.vDaemon.textContent = d.daemon === '1' ? ('pid ' + d.pid) : '未运行';
    el.vDaemon.className = 'v mono' + (d.daemon === '1' ? ' ok' : ' bad');
    if (el.vDaemonSub) el.vDaemonSub.textContent = d.daemon === '1' ? '后台复核中' : '守护没跑起来';

    el.vUptime.textContent = human(d.uptime);
    if (el.vUptimeSub) el.vUptimeSub.textContent = '开机以来';
    el.vMask.textContent = d.mask_on === '1' ? '开启' : '关闭';
    el.vMask.className = 'v' + (d.mask_on === '1' ? (d.mask_active === '1' ? ' ok' : ' warn') : '');
    if (el.vMaskSub) {
      el.vMaskSub.textContent = d.mask_on === '1'
        ? (d.mask_active === '1' ? ('tmpfs 接管 · ' + (d.masked || 0) + ' 个 .ko') : '开关开着但未接管')
        : 'tmpfs 未接管';
    }
    if (el.vMaskActive) el.vMaskActive.textContent = d.mask_active === '1' ? '是（tmpfs）' : '否';
    if (el.vMasked) el.vMasked.textContent = d.masked || '0';
    el.vMode.textContent = d.mode === 'monitor' ? '监控' : '卸载';
    el.vMode.className = 'v' + (d.mode === 'monitor' ? ' warn' : ' ok');
    if (el.vModeSub) el.vModeSub.textContent = '每 ' + (d.interval || '5') + 's 复核';

    el.vModel.textContent = d.model || '—';
    el.vKernel.textContent = d.kernel || '—';
    el.vRoot.textContent = d.root || '—';

    segOn(el.segMode, 'mode', d.mode);
    segOn(el.segIv, 'iv', d.interval);

    el.btnMask.textContent = d.mask_on === '1' ? '已开启' : '已关闭';
    el.btnMask.className = 'btn' + (d.mask_on === '1' ? ' on' : '');

    // 游戏守护
    if (el.btnGame) {
      el.btnGame.textContent = d.game_on === '1' ? '已开启' : '已关闭';
      el.btnGame.className = 'btn' + (d.game_on === '1' ? ' on' : '');
    }
    if (el.vGameHits) el.vGameHits.textContent = d.game_hits || '0';
    if (el.vGameDel) el.vGameDel.textContent = d.game_del || '0';
    if (el.vGameBytes) {
      var gb = parseInt(d.game_bytes, 10) || 0;
      el.vGameBytes.textContent = gb > 1048576 ? (Math.round(gb / 1048576 * 10) / 10 + ' MB')
        : (gb > 1024 ? Math.round(gb / 1024) + ' KB' : (gb + ' B'));
      el.vGameBytes.className = 'mono';
    }
    if (el.vGameLast) {
      var gl = parseInt(d.game_last, 10) || 0;
      el.vGameLast.textContent = gl > 0 ? human(Math.max(0, Math.round(Date.now() / 1000) - gl)) + '前' : '还没扫过';
    }
    if (el.btnGameDry) {
      var isDry = d.game_dry !== '0';
      el.btnGameDry.setAttribute('data-dry', isDry ? '1' : '0');
      el.btnGameDry.textContent = isDry ? '试跑（不删）' : '真删模式';
      el.btnGameDry.className = 'btn' + (isDry ? ' on' : ' danger');
      el.btnGameDry.className = 'btn' + (d.game_dry === '1' ? ' on' : '');
    }

    // Key / TEE
    if (el.vKm) el.vKm.textContent = d.kf_km || '—';
    if (el.vTee) {
      el.vTee.textContent = d.kf_tee || '—';
      el.vTee.className = /可用|运行中|存在|目录/.test(d.kf_tee || '') ? 'ok' : 'warn';
    }
    if (el.vAtt) {
      el.vAtt.textContent = d.kf_att || '—';
      el.vAtt.className = (d.kf_att || '').indexOf('缺') >= 0 ? 'warn' : 'ok';
    }
    if (el.vKfMods) {
      var ki = parseInt(d.kf_packs_inst, 10) || 0;
      var kt = parseInt(d.kf_packs_total, 10) || 0;
      el.vKfMods.textContent = kt ? (ki + '/' + kt + ' 已安装') : '无';
      el.vKfMods.className = (kt && ki < kt) ? 'warn' : 'ok';
    }
    if (el.kfStatus) {
      var prog = (d.kf_prog || '').trim();
      if (!prog) {
        el.kfStatus.textContent = '空闲';
        el.kfStatus.className = 'kf-status';
      } else if (/^完成/.test(prog) && (parseInt(d.kf_prog_age, 10) > 120 || parseInt(d.kf_prog_age, 10) < 0)) {
        el.kfStatus.textContent = '空闲';
        el.kfStatus.className = 'kf-status';
      } else if (/^\d\/4|^完成/.test(prog)) {
        var busy = !/^完成/.test(prog);
        el.kfStatus.textContent = busy ? (prog + ' …') : prog;
        el.kfStatus.className = 'kf-status' + (busy ? ' busy' : '');
      }
    }
    if (el.vKfBurn) {
      var burn = d.kf_burn || '';
      if (burn.indexOf('已装') >= 0 && burn.indexOf('未装') < 0) {
        el.vKfBurn.textContent = '已装';
        el.vKfBurn.className = 'ok';
      } else {
        el.vKfBurn.textContent = '未装 · 修复时自动安装';
        el.vKfBurn.className = 'info';
      }
    }


    var _loaded = d.loaded && d.loaded !== '-';
    el.modeHint.textContent = d.mode === 'monitor'
      ? ('监控模式：只记录不卸载。' + (_loaded ? '当前 inte 仍在内核里，所以 /proc/inte_ko 这类节点还在，文件遮蔽也只管磁盘文件。' : '看到「有目标」的日志说明检测确实还在。'))
      : '卸载模式：发现 inte 立刻 rmmod，让它失去效果（/proc 节点也会一起消失）。';

    if (el.teeLog) {
      var tlog = b64utf8(d.log64);
      el.teeLog.textContent = tlog.trim() || '（暂无）';
    }
    var log = b64utf8(d.log64);
    if (log.trim()) el.log.textContent = log;
    else if (el.log.textContent.length < 2) el.log.textContent = '（暂无）';
  }

  function segOn(box, attr, cur) {
    if (!box) return;
    var bs = box.querySelectorAll('button');
    for (var i = 0; i < bs.length; i++) {
      var v = bs[i].getAttribute('data-' + attr);
      var hit = (attr === 'iv')
        ? (parseInt(v, 10) === parseInt(cur, 10))
        : (v === cur);
      bs[i].className = hit ? 'on' : '';
    }
  }

  function refresh() {
    return sh('sh ' + MOD + '/bin/status.sh').then(function (out) {
      var d = parse(out);
      if (!d.state) throw new Error('状态脚本没有输出');
      render(d);
      return d;
    });
  }

  function bus(btn, txt) {
    if (btn) { btn.disabled = true; btn._t = btn.textContent; btn.textContent = txt || '处理中…'; }
  }
  function unbus(btn) {
    if (btn) { btn.disabled = false; if (btn._t) btn.textContent = btn._t; }
  }

  function act(btn, cmd, okMsg) {
    bus(btn);
    return sh('sh ' + MOD + '/bin/ctl.sh ' + cmd)
      .then(function (out) {
        toast(okMsg || '完成');
        var tail = String(out || '').trim().split('\n').pop();
        if (tail) el.log.textContent = tail;
        return refresh();
      })
      .catch(function (e) { toast('失败：' + (e && e.message ? e.message : e)); })
      .then(function () { unbus(btn); });
  }

  // ── 事件 ─────────────────────────────────────────────────────────────
  if (el.segMode) {
    el.segMode.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('button') : e.target;
      var m = b && b.getAttribute('data-mode');
      if (!m) return;
      act(null, 'mode ' + m, '模式已切换为' + (m === 'monitor' ? '监控' : '卸载'));
    });
  }
  if (el.segIv) {
    el.segIv.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('button') : e.target;
      var iv = b && b.getAttribute('data-iv');
      if (!iv) return;
      act(null, 'interval ' + iv, '间隔改为 ' + iv + 's');
    });
  }
  if (el.btnClear) el.btnClear.addEventListener('click', function () { act(el.btnClear, 'clear', '清除指令已执行'); });
  if (el.btnRefresh) el.btnRefresh.addEventListener('click', function () {
    bus(el.btnRefresh, '刷新中…');
    refresh().then(function () { toast('已刷新'); unbus(el.btnRefresh); }).catch(function () { unbus(el.btnRefresh); });
  });
  if (el.btnMask) el.btnMask.addEventListener('click', function () {
    var on = el.btnMask.textContent.indexOf('已开启') >= 0;
    act(el.btnMask, 'mask ' + (on ? '0' : '1'), on ? '遮蔽已关闭' : '遮蔽已开启');
  });
  if (el.logFold) {
    var toggle = function () { el.log.classList.toggle('hide'); el.logFold.classList.toggle('closed'); };
    el.logFold.addEventListener('click', toggle);
    el.logFold.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
    });
  }

  // ── 游戏 / Key / 更新 ────────────────────────────────────────────────
  function shq(str) { return "'" + String(str).replace(/'/g, "'\\''") + "'"; }

  function toggleLog(box, btn, onTxt, offTxt) {
    if (!box) return;
    var hidden = box.className.indexOf('hide') >= 0;
    box.className = hidden ? 'log' : 'log hide';
    if (btn) btn.textContent = hidden ? offTxt : onTxt;
  }

  if (el.btnGame) el.btnGame.addEventListener('click', function () {
    var on = el.btnGame.textContent.indexOf('已开启') >= 0;
    act(el.btnGame, 'game ' + (on ? 'off' : 'on'), on ? '游戏守护已关闭' : '游戏守护已开启');
  });
  if (el.btnGameDry) el.btnGameDry.addEventListener('click', function () {
    var isDry = el.btnGameDry.getAttribute('data-dry') !== '0';
    if (isDry) {
      // 试跑 → 真删：要点两次，防误触
      if (el.btnGameDry.getAttribute('data-armed') !== '1') {
        el.btnGameDry.setAttribute('data-armed', '1');
        el.btnGameDry.textContent = '再点一次开启真删';
        toast('真删会真的删除文件，再点一次确认');
        clearTimeout(el.btnGameDry._at);
        el.btnGameDry._at = setTimeout(function () {
          el.btnGameDry.removeAttribute('data-armed');
          el.btnGameDry.textContent = '试跑（不删）';
        }, 4000);
        return;
      }
      el.btnGameDry.removeAttribute('data-armed');
      act(el.btnGameDry, 'game live', '已切换到真删模式');
    } else {
      act(el.btnGameDry, 'game dry', '已切回试跑模式');
    }
  });
  if (el.btnGameLog) el.btnGameLog.addEventListener('click', function () {
    toggleLog(el.gameLog, el.btnGameLog, '命中记录', '收起记录');
    if (el.gameLog.className.indexOf('hide') < 0) {
      sh('sh ' + MOD + '/bin/game.sh --log 40').then(function (log) {
        el.gameLog.textContent = String(log || '').trim() || '（暂无记录）';
      }).catch(function () {});
    }
  });
  function setKfStatus(txt, busy) {
    if (!el.kfStatus) return;
    el.kfStatus.textContent = txt;
    el.kfStatus.className = 'kf-status' + (busy ? ' busy' : '');
  }

  function kfFixAll() {
    var btn = el.btnKfFix;
    if (!btn) return;
    if (btn.getAttribute('data-armed') !== '1') {
      btn.setAttribute('data-armed', '1');
      btn.textContent = '再点一次开始修复';
      toast('再点一次开始修复');
      clearTimeout(btn._at);
      btn._at = setTimeout(function () {
        btn.removeAttribute('data-armed');
        btn.textContent = '一键修复 Key 状态';
      }, 3500);
      return;
    }
    btn.removeAttribute('data-armed');
    clearTimeout(btn._at);
    btn.disabled = true;
    btn.textContent = '修复中…';
    setKfStatus('正在启动修复流程…', true);
    sh('sh ' + MOD + '/bin/ctl.sh kf repair').then(function (out) {
      setKfStatus(String(out || '').replace(/^OK\|/, '').trim() || '修复流程已启动', true);
      toast('修复流程已启动，稍后自动刷新');
      var n = 0;
      var timer = setInterval(function () {
        n++;
        refresh().catch(function () {});
        if (n >= 24) {
          clearInterval(timer);
          if (el.btnKfFix) { el.btnKfFix.disabled = false; el.btnKfFix.textContent = '一键修复 Key 状态'; }
        }
      }, 5000);
    }).catch(function (e) {
      setKfStatus('启动失败：' + (e && e.message ? e.message : e), false);
      btn.disabled = false;
      btn.textContent = '一键修复 Key 状态';
    });
  }
  // 清理残留 / 卸载模块（都要点两次）
  function dangerAction(btn, cmd, armedText, doneMsg) {
    if (!btn) return;
    if (btn.getAttribute('data-armed') !== '1') {
      btn.setAttribute('data-armed', '1');
      btn._t = btn.textContent;
      btn.textContent = armedText;
      toast('再点一次确认');
      clearTimeout(btn._at);
      btn._at = setTimeout(function () {
        btn.removeAttribute('data-armed');
        if (btn._t) btn.textContent = btn._t;
      }, 4000);
      return;
    }
    btn.removeAttribute('data-armed');
    clearTimeout(btn._at);
    btn.disabled = true;
    sh('sh ' + MOD + '/bin/ctl.sh ' + cmd).then(function (out) {
      var text = String(out || '').trim();
      if (el.log) { el.log.className = 'log'; el.log.textContent = text || doneMsg; }
      toast(doneMsg);
    }).catch(function (e) {
      toast('失败：' + (e && e.message ? e.message : e));
    }).then(function () {
      btn.disabled = false;
      if (btn._t) btn.textContent = btn._t;
      return refresh().catch(function () {});
    });
  }

  if (el.btnCleanup) el.btnCleanup.addEventListener('click', function () {
    dangerAction(el.btnCleanup, 'clean', '再点一次清理', '残留已清理');
  });
  if (el.btnUninstall) el.btnUninstall.addEventListener('click', function () {
    dangerAction(el.btnUninstall, 'uninstall yes', '再点一次卸载', '已标记卸载，重启后生效');
  });

  if (el.btnKfFix) el.btnKfFix.addEventListener('click', kfFixAll);

  if (el.btnKfLog) el.btnKfLog.addEventListener('click', function () {
    if (!el.kfLog) return;
    var hidden = el.kfLog.className.indexOf('hide') >= 0;
    el.kfLog.className = hidden ? 'log' : 'log hide';
    if (hidden) {
      sh('sh ' + MOD + '/bin/ctl.sh kf log 60').then(function (out) {
        if (el.kfLog) el.kfLog.textContent = String(out || '').trim() || '（暂无记录）';
      }).catch(function () {});
    }
  });

  if (el.teeLogFold) {
    var toggleTeeLog = function () {
      if (!el.teeLog) return;
      var hidden = el.teeLog.className.indexOf('hide') >= 0;
      el.teeLog.className = hidden ? 'log' : 'log hide';
      var ic = el.teeLogFold.querySelector('i');
      if (ic) ic.textContent = hidden ? '▴' : '▾';
    };
    el.teeLogFold.addEventListener('click', toggleTeeLog);
    el.teeLogFold.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleTeeLog(); }
    });
  }

  if (el.teeDescToggle) {
    var toggleDesc = function () {
      if (!el.teeDesc) return;
      var hidden = el.teeDesc.className.indexOf('hide') >= 0;
      el.teeDesc.className = hidden ? '' : 'hide';
      el.teeDescToggle.className = 'fold-row' + (hidden ? ' open' : '');
    };
    el.teeDescToggle.addEventListener('click', toggleDesc);
    el.teeDescToggle.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleDesc(); }
    });
  }
  if (el.btnKfScan) el.btnKfScan.addEventListener('click', function () {
    bus(el.btnKfScan, '检测中…');
    refresh().then(function () { toast('已重新检测'); unbus(el.btnKfScan); }).catch(function () { unbus(el.btnKfScan); });
  });
  if (el.btnKfPacks) el.btnKfPacks.addEventListener('click', function () {
    bus(el.btnKfPacks, '读取中…');
    loadPacks().then(function () { toast('已刷新修复包'); }).catch(function () { toast('读取失败'); })
      .then(function () { unbus(el.btnKfPacks); });
  });

  // ── 修复包：列表 / 两段式安装 ────────────────────────────────────────
  function packRows(txt) {
    var out = [];
    String(txt || '').split('\n').forEach(function (line) {
      var p = line.split('|');
      if (p.length < 6) return;
      out.push({ idx: p[0], name: p[1], desc: p[2], size: p[3], src: p[4], inst: p[5] === '1' });
    });
    return out;
  }

  function renderPacks(rows) {
    if (!el.kfPacks) return;
    el.kfPacks.innerHTML = '';
    if (!rows.length) {
      el.kfPacks.textContent = '没有修复包（内置目录 keyfix/ 为空）';
      return;
    }
    rows.forEach(function (p) {
      var row = document.createElement('div');
      row.className = 'pack' + (p.inst ? ' on' : '');
      var txt = document.createElement('div');
      txt.className = 'packt';
      var b = document.createElement('b');
      b.textContent = '[' + p.idx + '] ' + p.desc;
      var s = document.createElement('span');
      s.className = 'tag';
      s.textContent = p.src + ' · ' + p.size + (p.inst ? ' · 已安装' : ' · 未安装');
      txt.appendChild(b);
      txt.appendChild(s);
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'btn' + (p.inst ? ' on' : '');
      btn.textContent = p.inst ? '更新' : '安装';
      btn.addEventListener('click', function () { armInstall(btn, p); });
      row.appendChild(txt);
      row.appendChild(btn);
      el.kfPacks.appendChild(row);
    });
  }

  function loadPacks() {
    return sh('sh ' + MOD + '/bin/key.sh --packs').then(function (out) {
      renderPacks(packRows(out));
    });
  }

  function armInstall(btn, p) {
    if (btn.getAttribute('data-armed') === '1') {
      btn.removeAttribute('data-armed');
      clearTimeout(btn._at);
      btn.disabled = true;
      btn.textContent = '安装中…';
      if (el.kfLog) {
        el.kfLog.className = 'log';
        el.kfLog.textContent = '正在安装 ' + p.name + ' …';
      }
      sh('sh ' + MOD + '/bin/ctl.sh kf install ' + shq(p.name)).then(function (out) {
        if (el.kfLog) el.kfLog.textContent = String(out || '（无输出）').trim();
        toast('已交给模块管理器，重启后生效');
        btn.disabled = false;
        btn.textContent = p.inst ? '更新' : '安装';
        setTimeout(function () { loadPacks().catch(function () {}); }, 1200);
      }).catch(function (e) {
        if (el.kfLog) el.kfLog.textContent = '安装失败：' + (e && e.message ? e.message : e);
        btn.disabled = false;
        btn.textContent = p.inst ? '更新' : '安装';
        toast('安装失败');
      });
    } else {
      btn.setAttribute('data-armed', '1');
      btn.textContent = '再点确认';
      toast('再点一次安装 ' + p.name);
      clearTimeout(btn._at);
      btn._at = setTimeout(function () {
        if (btn.getAttribute('data-armed') === '1') {
          btn.removeAttribute('data-armed');
          btn.textContent = p.inst ? '更新' : '安装';
        }
      }, 3500);
    }
  }

  // ── 轮询 ─────────────────────────────────────────────────────────────
  var timer = null, busy = false;
  function tick() {
    if (busy || document.hidden) return;
    busy = true;
    refresh().catch(function () {}).then(function () { busy = false; });
  }
  function start() { if (!timer) timer = setInterval(tick, POLL); }
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { clearInterval(timer); timer = null; }
    else { refresh().catch(function () {}); start(); }
  });

  // ── mock：浏览器里调样式用，不连真机 ──────────────────────────────────
  function mockLog() {
    return '[06-11 05:58:01] [daemon] 启动 pid=2741 模式=unload 间隔=5s\n'
      + '[06-11 05:58:01] [hit] 检测到 inte，开始卸载\n'
      + '[06-11 05:58:01] [rmmod] inte 已卸载\n'
      + '[06-11 05:58:01] [done] 复核通过，inte 已不在内核里';
  }
  // 浏览器没有 TextEncoder 的旧内核里也能用的 base64(UTF-8)
  function b64enc(str) {
    try { return btoa(unescape(encodeURIComponent(str))); } catch (e) { return ''; }
  }
  function mockRun(cmd) {
    var base = 'unlocked=1\nversion=v1.2.0\nstate=normal\nmode=unload\ninterval=5\n'
      + 'loaded=-\nnodes=0\nmask_on=0\nmask_active=0\nmasked=0\npid=2741\ndaemon=1\nuptime=5340\n'
      + 'model=OnePlus PLK110\nkernel=6.1.75-android14\nroot=KernelSU\n'
      + 'game_on=1\ngame_dry=1\ngame_hits=37\ngame_del=0\n'
      + 'kf_km=qti\nkf_tee=运行中\nkf_att=已配补丁级别\n'
            + 'log64=' + b64enc(mockLog());
    if (cmd.indexOf('status.sh') >= 0) return base;
    if (cmd.indexOf('--packs') >= 0) {
      return '1|01-TEE-AutoList.zip|TEE 白名单自动维护（阿灵）|5.5M|内置|0\n'
        + '2|02-TEESimulator-RS.zip|TEE 模拟器 · 软件 attestation|2.6M|内置|1\n'
        + '3|03-fix-key-state.zip|修复 Key 状态 · Soter / RKP|95K|内置|0';
    }
    if (cmd.indexOf('game.sh --log') >= 0) return '[dry] 命中 /data/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/20261007.xlog (1.2 MB)';
    return 'mock: ' + cmd;
  }


  // ── 卡密锁 ────────────────────────────────────────────────────────────
  var lockEl = document.getElementById('lock');
  var lockKey = document.getElementById('lockKey');
  var lockBtn = document.getElementById('lockBtn');
  var lockMsg = document.getElementById('lockMsg');
  var UNLOCKED = false;

  function lockShow(on) {
    if (!lockEl) return;
    lockEl.className = on ? 'lock show' : 'lock';
    lockEl.setAttribute('aria-hidden', on ? 'false' : 'true');
    document.body.style.overflow = on ? 'hidden' : '';
  }

  function lockSay(msg, ok) {
    if (!lockMsg) return;
    lockMsg.textContent = msg || '';
    lockMsg.className = 'lock-msg' + (ok ? ' ok' : '');
  }

  function lockSubmit() {
    var v = (lockKey && lockKey.value || '').trim();
    if (!v) { lockSay('请输入卡密'); return; }
    lockBtn.disabled = true;
    lockSay('正在验证…', true);
    sh('sh ' + MOD + '/bin/ctl.sh auth login ' + shq(v)).then(function (out) {
      var t = String(out || '').trim();
      if (t.indexOf('OK|') === 0) {
        UNLOCKED = true;
        lockSay('解锁成功', true);
        if (lockKey) lockKey.value = '';
        setTimeout(function () { lockShow(false); }, 400);
      } else {
        lockSay(t.replace(/^NO\|/, '') || '卡密不对');
        if (lockKey) lockKey.value = '';
      }
    }).catch(function () {
      lockSay('验证失败，重试一次');
    }).then(function () {
      lockBtn.disabled = false;
    });
  }

  if (lockBtn) lockBtn.addEventListener('click', lockSubmit);
  if (lockKey) lockKey.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') lockSubmit();
  });
  lockShow(true);

  // 防止未解锁时用 Tab 走到下面的控件
  document.addEventListener('focusin', function (e) {
    if (UNLOCKED || !lockEl) return;
    if (lockEl.contains(e.target)) return;
    if (lockKey) lockKey.focus();
  });

  // ── 底部标签栏 + 横向滑动切页 ─────────────────────────────────────────
  var TABS = ['main', 'tee', 'about'];
  var glider = document.querySelector('.tabbar .glider');
  var viewport = document.getElementById('viewport');
  var SWITCH_DX = 56;

  function tabBtn(name) { return document.querySelector('.tab[data-tab="' + name + '"]'); }
  function pageEl(name) { return document.getElementById('page-' + name); }
  function currentTab() {
    var t = (location.hash || '').replace('#', '');
    return TABS.indexOf(t) >= 0 ? t : 'main';
  }

  function placeGlider(btn, extra) {
    if (!glider || !btn) return;
    var bar = glider.parentNode;
    if (!bar) return;
    var br = btn.getBoundingClientRect();
    var pr = bar.getBoundingClientRect();
    var left = br.left - pr.left - (bar.clientLeft || 0);
    glider.style.width = br.width + 'px';
    glider.style.transform = 'translateX(' + (left + (extra || 0)) + 'px)';
  }

  function showTab(name) {
    if (TABS.indexOf(name) < 0) name = 'main';
    for (var i = 0; i < TABS.length; i++) {
      var pg = pageEl(TABS[i]);
      if (pg) pg.className = 'page' + (TABS[i] === name ? ' on' : '');
    }
    var btns = document.querySelectorAll('.tab');
    for (var j = 0; j < btns.length; j++) {
      var on = btns[j].getAttribute('data-tab') === name;
      btns[j].className = 'tab' + (on ? ' on' : '');
      btns[j].setAttribute('aria-selected', on ? 'true' : 'false');
    }
    placeGlider(tabBtn(name), 0);
    if (window.requestAnimationFrame) requestAnimationFrame(function () { placeGlider(tabBtn(name), 0); });
    setTimeout(function () { placeGlider(tabBtn(name), 0); }, 260);
  }

  function goTab(name, dir) {
    showTab(name);
    var pg = pageEl(name);
    if (dir && pg && pg.animate) {
      pg.animate(
        [{ transform: 'translateX(' + (dir * 70) + 'px)', opacity: .35 }, { transform: 'none', opacity: 1 }],
        { duration: 280, easing: 'cubic-bezier(.22,.8,.3,1)' }
      );
    }
    if (location.hash !== '#' + name) location.hash = name;
  }

  (function bindTabs() {
    var btns = document.querySelectorAll('.tab');
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener('click', function () { goTab(this.getAttribute('data-tab'), 0); });
    }
    window.addEventListener('hashchange', function () { showTab(currentTab()); });
    window.addEventListener('resize', function () { placeGlider(tabBtn(currentTab()), 0); });
    // 首帧直接落位，别从 0 滑过去（否则深色文字会先落在暗底上看不清）
    if (glider) glider.classList.add("no-anim");
    showTab(currentTab());
    (function swipeHint() {
      var tip = document.getElementById('swipeHint');
      if (!tip) return;
      setTimeout(function () { tip.className = 'swipe-hint show'; }, 600);
      setTimeout(function () { tip.className = 'swipe-hint'; }, 3600);
    })();
    setTimeout(function () {
      placeGlider(tabBtn(currentTab()), 0);
      if (glider) glider.classList.remove("no-anim");
    }, 120);
    if (window.ResizeObserver) {
      try {
        var ro = new ResizeObserver(function () { placeGlider(tabBtn(currentTab()), 0); });
        ro.observe(document.querySelector('.tabbar'));
        ro.observe(tabBtn('main'));
      } catch (e) {}
    }
    window.addEventListener('pageshow', function () { placeGlider(tabBtn(currentTab()), 0); });
    window.addEventListener('load', function () {
      placeGlider(tabBtn(currentTab()), 0);
      setTimeout(function () { placeGlider(tabBtn(currentTab()), 0); }, 300);
    });
  })();

  // 横向滑动切页：监听在 document 上，内容区和底部栏都能划
  (function bindSwipe() {
    var drag = null;

    function threshold(fromBar) {
      var w = window.innerWidth || 360;
      if (fromBar) return Math.max(58, w * 0.16);          // 底栏：更严格，防误触
      return Math.max(44, Math.min(96, w * 0.12));          // 内容区
    }

    function start(x, y, target) {
      // 屏幕左右边缘留给系统返回手势
      var w = window.innerWidth || 360;
      if (x < 26 || x > w - 26) { drag = null; return; }
      var fromBar = !!(target && target.closest && target.closest('.tabbar'));
      drag = { x0: x, y0: y, dx: 0, dy: 0, lock: null, bar: fromBar };
    }

    function move(x, y) {
      if (!drag) return;
      var dx = x - drag.x0;
      var dy = y - drag.y0;
      drag.dx = dx;
      drag.dy = dy;
      if (!drag.lock) {
        if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return;
        drag.lock = Math.abs(dx) > Math.abs(dy) * 1.15 ? 'x' : 'y';
        if (drag.lock === 'x') {
          if (glider) glider.classList.add('dragging');
          if (!drag.bar) {
            var c0 = pageEl(currentTab());
            if (c0) c0.classList.add('dragging');
          }
        }
      }
      if (drag.lock !== 'x') return;
      var w = window.innerWidth || 360;
      var limit = w * 0.42;
      var d = Math.max(-limit, Math.min(limit, dx));
      // 从底部栏起手时，后面的页面完全不动
      if (!drag.bar) {
        var cur = pageEl(currentTab());
        if (cur) {
          cur.style.transform = 'translateX(' + (d * 0.2) + 'px)';
          cur.style.opacity = String(1 - Math.min(0.4, Math.abs(d) / w * 0.9));
        }
      }
      // 只在从底部栏起手时让胶囊跟手；滑页面时底部栏完全不动，避免两个手势打架
      if (drag.bar) placeGlider(tabBtn(currentTab()), d * 0.5);
    }

    function suppressNextClick() {
      var fn = function (ev) { ev.stopPropagation(); ev.preventDefault(); };
      document.addEventListener('click', fn, true);
      setTimeout(function () { document.removeEventListener('click', fn, true); }, 420);
    }

    function finish() {
      if (!drag) return;
      var dx = drag.dx || 0;
      var lock = drag.lock;
      var fromBar = !!drag.bar;
      var curTab = currentTab();
      drag = null;
      if (glider) glider.classList.remove('dragging');
      var cur = pageEl(curTab);
      if (cur) { cur.classList.remove('dragging'); cur.style.transform = ''; cur.style.opacity = ''; }

      if (lock === 'x' && Math.abs(dx) > threshold(fromBar)) {
        // 内容区：从右往左滑（dx<0）→ 翻到下一页；从左往右 → 上一页
        // 底部栏：手指往左→胶囊落左边一页，手指往右→落右边一页（跟手）
        var step = fromBar ? (dx < 0 ? -1 : 1) : (dx < 0 ? 1 : -1);
        var idx = TABS.indexOf(curTab) + step;
        if (idx >= 0 && idx < TABS.length) {
          suppressNextClick();
          goTab(TABS[idx], step); // 进场方向：下一页从右滑入，上一页从左滑入
          return;
        }
      }
      // 底栏上划了一点但没到阈值：只算误触，别顺带触发标签点击
      if (fromBar && Math.abs(dx) > 8) suppressNextClick();
      showTab(curTab);
    }

    if ('ontouchstart' in window) {
      document.addEventListener('touchstart', function (e) {
        if (e.touches.length !== 1) { drag = null; return; }
        var t = e.touches[0];
        start(t.clientX, t.clientY, e.target);
      }, { passive: true });
      document.addEventListener('touchmove', function (e) {
        if (!drag || e.touches.length !== 1) return;
        var t = e.touches[0];
        move(t.clientX, t.clientY);
      }, { passive: true });
      document.addEventListener('touchend', finish, { passive: true });
      document.addEventListener('touchcancel', finish, { passive: true });
    } else {
      var down = false;
      document.addEventListener('mousedown', function (e) { down = true; start(e.clientX, e.clientY, e.target); });
      document.addEventListener('mousemove', function (e) { if (down) move(e.clientX, e.clientY); });
      document.addEventListener('mouseup', function () { if (down) { down = false; finish(); } });
    }
  })();

  refresh().catch(function (e) {
    el.stateTxt.textContent = '桥接不可用';
    el.stateSub.textContent = '请从 KernelSU 管理器打开本页（' + (e && e.message ? e.message : 'unknown') + '）';
    el.hero.className = 'card hero bad';
    el.chip.textContent = '未连接';
  });
  start();
  loadPacks().catch(function () {});
})();

/* ── 液态玻璃镜面：拖动跟随手指，松手回到激活项 ───────────────── */
(function __sheen() {
  var bar = document.querySelector('.tabbar');
  var sh = document.querySelector('.sheen');
  if (!bar || !sh) return;

  function place(cx, animate) {
    var w = bar.getBoundingClientRect().width || bar.offsetWidth || 1;
    var sw = sh.getBoundingClientRect().width || w * 0.42;
    var x = Math.max(0, Math.min(w - sw, cx - sw / 2));
    if (animate === false) sh.classList.add('dragging');
    else sh.classList.remove('dragging');
    sh.style.transform = 'translateX(' + x + 'px)';
  }

  function toActive(animate) {
    var on = bar.querySelector('.tab.on');
    var b = bar.getBoundingClientRect();
    var t = on ? on.getBoundingClientRect() : null;
    place(t ? t.left - b.left + t.width / 2 : b.width / 2, animate);
  }

  bar.addEventListener('touchstart', function (e) {
    var t = e.touches && e.touches[0];
    if (t) place(t.clientX - bar.getBoundingClientRect().left, false);
  }, { passive: true });

  bar.addEventListener('touchmove', function (e) {
    var t = e.touches && e.touches[0];
    if (t) place(t.clientX - bar.getBoundingClientRect().left, false);
  }, { passive: true });

  bar.addEventListener('touchend', function () { toActive(true); }, { passive: true });
  bar.addEventListener('touchcancel', function () { toActive(true); }, { passive: true });
  bar.querySelectorAll('.tab').forEach(function (b) {
    b.addEventListener('click', function () { setTimeout(function () { toActive(true); }, 0); });
  });

  toActive(false);
  setTimeout(function () { toActive(false); }, 120);
})();

/* ── 液态玻璃：SVG 位移贴图做边缘折射（对应 index 里的 #lgWarp） ────
   做法参考 github.com/UmarGit/liquid-glass（feImage 位移贴图 + backdrop-filter:url()），
   位移贴图改成运行时用 canvas 生成，不依赖外部图片。 */
(function __liquidLens() {
  var bar = document.querySelector('.tabbar');
  var map = document.getElementById('lgMap');
  if (!bar || !map) return;

  // 浏览器支持 backdrop-filter: url() 才启用，否则老实退回纯毛玻璃
  function supported() {
    try {
      return window.CSS && CSS.supports && (CSS.supports('backdrop-filter', 'url(#lgWarp)') ||
        CSS.supports('-webkit-backdrop-filter', 'url(#lgWarp)'));
    } catch (e) { return false; }
  }
  if (!supported()) return;

  // 生成位移贴图：中心中性(128)，越靠边偏折越大 → 像一块凸起的玻璃
  function makeMap(n) {
    var cv = document.createElement('canvas');
    cv.width = cv.height = n;
    var ctx = cv.getContext('2d');
    var img = ctx.createImageData(n, n);
    var d = img.data;
    var c = (n - 1) / 2;
    for (var y = 0; y < n; y++) {
      for (var x = 0; x < n; x++) {
        var dx = (x - c) / c;
        var dy = (y - c) / c;
        var r = Math.min(1, Math.sqrt(dx * dx + dy * dy) / 1.34);
        var i = (y * n + x) * 4;
        d[i] = 128 + dx * r * 127;
        d[i + 1] = 128 + dy * r * 127;
        d[i + 2] = 128;
        d[i + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
    return cv.toDataURL('image/png');
  }

  try { map.setAttribute('href', makeMap(96)); } catch (e) { return; }

  var lens = document.createElement('span');
  lens.className = 'lg-lens';
  lens.setAttribute('aria-hidden', 'true');
  bar.appendChild(lens);
})();
